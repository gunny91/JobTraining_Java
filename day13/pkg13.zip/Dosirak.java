package pkg13;

import java.util.Arrays;

public class Dosirak {
	private Saram saram ; //Saram ��ü
	private String dname ; //���ö� �̸�
	private int price ; //�ܰ�
	private String[] banchan ; //= new String[3] ; //���� 3��
	
	public Dosirak(Saram saram, String dname, int price, String[] banchan) {
		this.saram = saram;
		this.dname = dname;
		this.price = price;
		this.banchan = banchan;
	}
	public Saram getSaram() {
		return saram;
	}
	public String getDname() {
		return dname;
	}
	public int getPrice() {
		return price;
	}
	public String[] getBanchan() {
		return banchan;
	}
	@Override
	public String toString() {
		return "" + saram + "/" + dname + "/" + price + "/"
				+ Arrays.toString(banchan) + "]";
	}	
}
