package pkg13;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class MyArrayList2 {
	public static void main(String[] args) {
		
		List<Person> lists = new ArrayList<Person>();
		
		Person can1 = new Person("��ö��", 30, 40, 50);
		Person can2 = new Person("�ڿ���", 70, 80, 90);
		Person can3 = new Person("ȫ�浿", 40, 50, 60);
		
		lists.add(can1) ;lists.add(can2) ;lists.add(can3) ;
		
		System.out.println(lists.size());
		
		PrintList(lists);
		PrintFor(lists);	
	}
	private static void PrintList(List<Person> abcd) {
		System.out.println();
		System.out.println("������ ����Ʈ ���");
		System.out.println("�̸�\t����\t����\t����");
		
		Iterator<Person> it =  abcd.iterator() ;
		
		while( it.hasNext() ){
			Person person = it.next() ;
			
			String name = person.getName() ;
			double kor = person.getKor() ;
			double eng = person.getEng() ;
			double math = person.getMath() ;
			String imsi = name + "\t" + kor + "\t" + eng + "\t" + math ;
			System.out.println( imsi );
		}
	}

	private static void PrintFor(List<Person> asdf) {
		System.out.println();
		System.out.println("�̸��� ���� �� ��� ���");
		//�䱸 ���״�� ����ϼ���.
		for(Person person : asdf){			
			String name = person.getName() ;
			double kor = person.getKor() ;
			double eng = person.getEng() ;
			double math = person.getMath() ;
			double total = kor + eng + math ; 
			double average = (double)total / 3 ; 
			String imsi = name + "�� ���� : " + total + ", ��� : " + average ; 
			System.out.println( imsi );
		}
	}
}