package pkg13;
import java.text.DecimalFormat;
import java.util.Arrays;
//import java.text.SimpleDateFormat;
public class ImsiTest {
	public static void main(String[] args) {
//		SimpleDateFormat
		String pattern = "000,000.00" ;
		DecimalFormat df = new DecimalFormat(pattern) ;
		
		double su = 12345.6789 ;
		String result = df.format( su );
		
		System.out.println( result );

		String[] banchan = {"��ġ", "����"};
		System.out.println( Arrays.toString(banchan));
	}
}