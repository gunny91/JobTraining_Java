package pkg13;
public class template {
	public static void main(String[] args) {

	}
}