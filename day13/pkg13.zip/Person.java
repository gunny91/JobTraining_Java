package pkg13;
public class Person {
	private String name ;
	private double kor ;
	private double eng ;
	private double math ;
	
	public String getName() {
		return name;
	}
	public double getKor() {
		return kor;
	}
	public double getEng() {
		return eng;
	}
	public double getMath() {
		return math;
	}
	public Person() {
	
	}
	public Person(String name, double kor, double eng, double math) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
	}
	
}